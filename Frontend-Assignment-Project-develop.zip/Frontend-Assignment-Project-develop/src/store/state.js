export default {
  isSnackbar: {
    login: false,
    update: false,
    delete: false
  },
  products: [],
}