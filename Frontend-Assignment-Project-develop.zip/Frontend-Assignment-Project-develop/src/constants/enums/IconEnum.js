import * as MaterialIcon from '@mdi/js'

export const IconEnum = Object.freeze({
  TUNE: MaterialIcon.mdiTune,
  EDIT: MaterialIcon.mdiPencil,
  DELETE: MaterialIcon.mdiDelete
})